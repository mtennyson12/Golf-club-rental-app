
import { firestore } from './firebase';

function getAvailableClubs(location) {
  return firestore.collection('clubs')
    .where('location', '==', location)
    .get()
    .then(snapshot => snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
}

export default getAvailableClubs;
