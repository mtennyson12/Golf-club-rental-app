
import { firestore } from './firebase';

function addClub({ userId, name, description, price, location }) {
  return firestore.collection('clubs').add({
    userId,
    name,
    description,
    price,
    location,
    createdAt: new Date()
  });
}

export default addClub;
